// Usamos a classe Rectangle do Phaser como base visual para facilitar
export class Entity extends Phaser.GameObjects.Sprite {
    constructor(scene, x, y, texture) {
        super(scene, x, y, texture);
        
        // Adiciona o objeto na cena e ativa a física
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        // Impede que o objeto saia da tela
        this.body.setCollideWorldBounds(true);
    }

    // Método base para ser sobrescrito (Polimorfismo)
    update() {
        // Lógica padrão vazia
    }
}