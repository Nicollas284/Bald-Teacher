import { Entity } from './Entity.js';

// CLASSE MÃE DE INIMIGOS
export class Enemy extends Entity {
    constructor(scene, x, y, width, height, color, speed, damage) {
        super(scene, x, y, width, height, color);
        this.speed = speed;
        this.damage = damage;
    }

    // POLIMORFISMO: Comportamento padrão (ir atrás do player)
    update(player) {
        this.scene.physics.moveToObject(this, player, this.speed);
    }
}

// FILHO 1: Estudante
export class Student extends Enemy {
    constructor(scene, x, y) {
        super(scene, x, y,'inimigo', 50, 10); // Vermelho
        this.changeDirectionTimer = 0;
        this.setScale(2);
        this.body.setSize(30, 30);
        this.body.setOffset(10, 20);
        this.body.setCollideWorldBounds(true);
        this.body.setBounce(1);
    }

    // POLIMORFISMO: Estudante tem movimento errático, sobrescreve o update padrão
    update(player) {
        this.changeDirectionTimer++;
        if (this.changeDirectionTimer > 100) {
            // Muda a velocidade aleatoriamente
            this.body.setVelocity(Phaser.Math.Between(-100, 100), Phaser.Math.Between(-100, 100));
            this.changeDirectionTimer = 0;
        }
    }
}

// FILHO 2: Rato
export class Rat extends Enemy {
    constructor(scene, x, y) {
        super(scene, x, y, 15, 10, 0x7f8c8d, 120, 5); // Cinza e rápido
    }

    // POLIMORFISMO: O rato mantém o update do Enemy (moveToObject), não precisa sobrescrever
}

// FILHO 3: Boss
export class Boss extends Enemy {
    constructor(scene, x, y) {
        super(scene, x, y, 50, 50, 0x8e44ad, 80, 20); // Roxo e grande
        this.health = 100;
    }

    // Boss persegue lentamente, mas com força
    update(player) {
        super.update(player); // Reutiliza a lógica do pai (ir atrás do player)
    }
}