import { Entity } from './Entity.js';

export class Player extends Entity {
    constructor(scene, x, y) {
        super(scene, x, y, 'professor'); // Azul
        
        this.health = 3;
        this.speed = 150;
        this.hasSword = false;
        this.setScale(2.5);
        
        // Captura o teclado
        this.cursors = scene.input.keyboard.createCursorKeys();
        this.keyW = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
        this.keyA = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        this.keyS = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
        this.keyD = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
        this.keyC = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.C);
    }

    update() {
        this.body.setVelocity(0); // Reseta velocidade

        // Movimentação WASD ou Setas
        if (this.cursors.left.isDown || this.keyA.isDown) {
            this.body.setVelocityX(-this.speed);
        } else if (this.cursors.right.isDown || this.keyD.isDown) {
            this.body.setVelocityX(this.speed);
        }

        if (this.cursors.up.isDown || this.keyW.isDown) {
            this.body.setVelocityY(-this.speed);
        } else if (this.cursors.down.isDown || this.keyS.isDown) {
            this.body.setVelocityY(this.speed);
        }
    }

    takeDamage(amount) {
        this.health -= amount;
        if (this.health < 0) this.health = 0;
    }
}