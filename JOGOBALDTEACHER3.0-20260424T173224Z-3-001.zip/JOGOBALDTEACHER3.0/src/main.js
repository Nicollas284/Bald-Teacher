import { MenuScene } from './scenes/MenuScene.js';
import { Phase1Scene } from './scenes/Phase1Scene.js';
import { Phase2Scene } from './scenes/Phase2Scene.js';


const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: 'game-container',
    physics: {
        default: 'arcade',
        arcade: {
            debug: true 
        }
    },
    scene: [MenuScene, Phase1Scene, Phase2Scene]
    
     // Aqui você adicionará as outras fases
};

const game = new Phaser.Game(config);