import { Player } from '../entities/Player.js';

export class Phase2Scene extends Phaser.Scene {
    constructor() {
        super('Phase2Scene');
    }

    preload() {
        // Carrega o fundo novo
        this.load.image('fundo_fase2', './assets/fase2_banheiro.png');
        this.load.image('professor', './assets/professor.png');
    }

    create() {
        this.add.image(0, 0, 'fundo_fase2').setOrigin(0, 0);

        // 2. Instancia o Professor (Posição X: 400, Y: 300 - no meio da tela)
        this.player = new Player(this, 400, 300);

        // 3. Define os limites da tela para o professor não fugir do mapa
        this.physics.world.setBounds(0, 0, 800, 600);
    }

    update() {
        // 4. O comando que faz o professor escutar as setas do teclado e andar!
        if (this.player) {
            this.player.update();
        }
    }
}