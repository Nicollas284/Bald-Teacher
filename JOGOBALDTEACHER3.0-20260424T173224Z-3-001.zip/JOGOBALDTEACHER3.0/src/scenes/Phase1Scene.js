import { Player } from '../entities/Player.js';
import { Student } from '../entities/Enemies.js';
import { Hair } from '../entities/Hair.js';

export class Phase1Scene extends Phaser.Scene {
    constructor() {
        super('Phase1Scene');
    }
    preload() {
        // O primeiro nome ('professor') é o apelido da imagem no código.
        // O segundo é o caminho onde o arquivo está salvo.
        this.load.image('professor', './assets/professor.png');
        this.load.image('aluno', './assets/aluno.png');
        this.load.image('cabelo', './assets/cabelo.png');
        this.load.image('fundo_sala', './assets/fase1sala.png');
        this.load.image('gameover_img', './assets/gameover.png');
        this.load.image('inimigo', './assets/inimigo.png');
        this.load.image('coracao_cheio', './assets/coracao_cheio.png');
        this.load.image('coracao_vazio', './assets/coracao_vazio.png');
        this.load.audio('musica_fundo', './assets/musica_fase1.mp3');
        this.load.image('cabelo_vazio', './assets/cabelo_vazio.png');
    }

    create() {
        
        this.add.image(0, 0, 'fundo_sala').setOrigin(0, 0).setScale(0.5);
        this.musicaBGM = this.sound.add('musica_fundo', { loop: true, volume: 0.3 });
        this.musicaBGM.play();
        this.hairCollected = 0; // Variáveis de controle
        this.requiredHair = 5;

        // HUD
        this.scoreText = this.add.text(16, 16, 'Cabelos: 0 / 5', { fontSize: '20px', fill: '#fff' });
        {
        // HUD - Sistema de Corações
      
        // Criamos uma lista (Array) vazia para guardar as imagens dos corações
        this.coracoesUI = []; 
        // Repete 3 vezes para criar os 3 corações iniciais
        for (let i = 0; i < 3; i++) {
            // A matemática aqui faz o X andar pro lado: 30, depois 70, depois 110...
            let posX = 30 + (i * 40); 
            // Adiciona a imagem na tela (Ajuste o .setScale se a sua arte for muito grande)
            let imgCoracao = this.add.image(posX, 50, 'coracao_cheio').setScale(1.5);
            // Guarda essa imagem na nossa lista
            this.coracoesUI.push(imgCoracao);
        }
        this.cabelosUI = [];
        for (let i = 0; i < this.requiredHair; i++) {
        // Posicionamos um pouco abaixo dos corações ou no canto oposto
        let posX = 30 + (i * 35); 
        let imgCabelo = this.add.image(posX, 100, 'cabelo_vazio').setScale(1.2);
        
        this.cabelosUI.push(imgCabelo);
    }
    
    
    }

        // Instanciando Objetos
        this.player = new Player(this, 400, 300);
        
        // Grupos de colisão
        this.enemies = this.physics.add.group();
        this.hairs = this.physics.add.group();
        this.obstacles = this.physics.add.staticGroup();
        let mesaProf = this.add.rectangle(650, 250, 200, 80, 0x000000, 0);
        this.obstacles.add(mesaProf);

        let mesaAluno1 = this.add.rectangle(210, 415, 100, 60, 0x000000, 0);
        this.obstacles.add(mesaAluno1);

        let mesaAluno2 = this.add.rectangle(480, 415, 100, 60, 0x000000, 0);
        this.obstacles.add(mesaAluno2);

        let mesaAluno3 = this.add.rectangle(750, 415, 100, 60, 0x000000, 0);
        this.obstacles.add(mesaAluno3);

        let mesaAluno4 = this.add.rectangle(750, 565, 100, 60, 0x000000, 0);
        this.obstacles.add(mesaAluno4);

        let mesaAluno5 = this.add.rectangle(210, 565, 100, 60, 0x000000, 0);
        this.obstacles.add(mesaAluno5);

        let mesaAluno6 = this.add.rectangle(480, 565, 100, 60, 0x000000, 0);
        this.obstacles.add(mesaAluno6);

        let lousa = this.add.rectangle(400, 90, 700, 80, 0x000000, 0);
        this.obstacles.add(lousa);


        // Adicionando Estudantes
        this.enemies.add(new Student(this, 100, 100));
        this.enemies.add(new Student(this, 700, 100));
        this.enemies.add(new Student(this, 100, 500));
        this.enemies.add(new Student(this, 400, 100));
        this.enemies.add(new Student(this, 700, 500));


        // Espalhando Cabelos
        for (let i = 0; i < this.requiredHair; i++) {
            let rx = Phaser.Math.Between(50, 750);
            let ry = Phaser.Math.Between(150, 550);
            this.hairs.add(new Hair(this, rx, ry));
        }

        // Sistema de Colisões
        this.physics.add.overlap(this.player, this.hairs, this.collectHair, null, this);
        this.physics.add.collider(this.player, this.enemies, this.hitEnemy, null, this);
        this.physics.add.collider(this.player, this.obstacles);
        this.physics.add.collider(this.enemies, this.obstacles);
    }

    update() {
        // Atualiza o player
        this.player.update();

        // Atualiza os inimigos (Aqui acontece a mágica do Polimorfismo)
        this.enemies.getChildren().forEach(enemy => {
            enemy.update(this.player);
        });
    }

    collectHair(player, hair) {
        // 1. Remove o item do chão
        hair.destroy(); 

        // 2. Atualiza a silhueta do HUD
        if (this.hairCollected < this.requiredHair) {
            // OBS: Verifique se 'cabelo' é o nome certo da sua imagem colorida!
            this.cabelosUI[this.hairCollected].setTexture('cabelo');
        }

        // 3. Aumenta o contador matemático (sem texto na tela!)
        this.hairCollected++;

        // 4. Checa vitória e muda de fase
        if (this.hairCollected >= this.requiredHair) {
            
            // Pára a música da Fase 1
            this.musicaBGM.stop(); 
            
            // Inicia a próxima fase
            this.scene.start('Phase2Scene');
        }
    }

    hitEnemy(player, enemy) {
        // 1. Tira a vida DO PLAYER (player.health em vez de this.health)
       if (player.health <= 0) return;

        // 2. Tira a vida
        player.health -= 1;

        // 3. Atualiza os corações na tela
        if (player.health >= 0 && player.health < 3) {
            this.coracoesUI[player.health].setTexture('coracao_vazio');
        }

        // 4. Feedback visual
        player.setTint(0xff0000);
        this.time.delayedCall(200, () => player.clearTint());

        // 5. Checa se morreu
        if (player.health <= 0) {
            // Removemos a linha do "healthText" fantasma! Agora vai direto pro Game Over.
            this.gameOver();
        } else {
            // 6. Empurrão
            player.x += (player.x < enemy.x) ? -50 : 50;
            player.y += (player.y < enemy.y) ? -50 : 50;
        }
    }

    gameOver() {
    // 1. Para toda a física (ninguém mais se mexe)
    this.physics.pause();

    // 2. Muda a cor do professor para indicar derrota
    this.player.setTint(0x555555);
    this.musicaBGM.stop();    
    // 3. Adiciona a imagem de Game Over no centro da tela
    // Usamos 400, 300 porque é o meio de um jogo 800x600
    this.add.image(400, 300, 'gameover_img').setOrigin(0.5).setScale(0.3);
    // 4. Texto instruindo a reiniciar
    this.add.text(350, 550, 'Clique para tentar novamente', { 
        fontSize: '20px', 
        fill: '#fff',
        backgroundColor: '#000'
    }).setOrigin(0.3);

    // 5. Configura o clique para reiniciar o jogo
    this.input.once('pointerdown', (space) => {
        this.scene.restart();
    });
}
}